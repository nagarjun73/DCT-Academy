## Environment Variables

1. DB_URL=<DB_URL>
2. DB_NAME=<DB_NAME>
3. PORT=<PORT>