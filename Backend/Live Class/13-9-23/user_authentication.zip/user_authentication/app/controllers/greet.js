const greet = {}

greet.welcome = function (req, res) {
  res.json({ message: "welcome to the website" })
}

greet.goodbye = function (req, res) {
  res.json({ message: "Thank you for visiting us" })
}

module.exports = greet