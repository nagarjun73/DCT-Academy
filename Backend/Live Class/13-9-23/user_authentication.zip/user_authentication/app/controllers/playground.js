const bcrypt = require('bcryptjs')

const password = 'secret123'
bcrypt.genSalt()
  .then((salt) => {
    console.log(salt, salt.length);
    bcrypt.hash(password, salt)
      .then((encrypatedPassword) => {
        console.log(encrypatedPassword);
      })
  })