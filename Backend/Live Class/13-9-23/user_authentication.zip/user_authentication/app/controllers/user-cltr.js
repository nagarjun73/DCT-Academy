const { validationResult } = require('express-validator')
const _ = require('lodash')
const User = require('../model/user-model')
const bcryptjs = require('bcryptjs')
const jwt = require('jsonwebtoken')
const usersCltr = {}

usersCltr.register = async function (req, res) {
  try {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      res.status(400).json({ errors: errors.array() })
    } else {
      const body = _.pick(req.body, ['username', 'email', 'password'])
      const user = new User(body)
      const salt = await bcryptjs.genSalt()
      const hashedPassword = await bcryptjs.hash(user.password, salt)
      user.password = hashedPassword
      const userDoc = await user.save()
      res.json(userDoc)
    }
  } catch (e) {
    res.json(e)
  }
}

usersCltr.login = async (req, res) => {
  try {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      res.status(400).json({ errors: errors.array() })
    } else {
      const body = _.pick(req.body, ['email', 'password'])
      const user = await User.findOne({ email: body.email })
      if (user) {
        const result = await bcryptjs.compare(body.password, user.password)
        if (result) {
          //JWT token
          const token = jwt.sign({
            id: user._id
          }, process.env.JWT_SECRET)
          res.json({ token: token })
        } else {
          res.status(404).json({ error: 'invalid password' })
        }
      } else {
        res.status(404).json({ error: "invalid email / password" })
      }
    }
  } catch (e) {
    res.json(e)
  }
}

usersCltr.account = async (req, res) => {
  try {
    const user = await User.findById(req.userId)
    const resBody = _.pick(user, ['_id', 'username', 'email'])
    res.json(resBody)
  } catch (e) {
    res.json(e)
  }
}

module.exports = usersCltr