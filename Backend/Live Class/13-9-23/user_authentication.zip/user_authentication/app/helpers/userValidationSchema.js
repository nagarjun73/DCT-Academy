const usernameSchema = {
  isLength: {
    options: { min: 3 },
    errorMessage: 'username should be minimum 3 characters'
  }
}

const emailSchema = {
  isEmail: {
    errorMessage: "email format is invalid"
  }
}

const passwordSchema = {
  notEmpty: {
    errorMessage: "password is required"
  },
  isLength: {
    options: { min: 8, max: 128 },
    errorMessage: 'password should be between 8 - 128 characters long'
  }
}

////////////////////////////
const userRegisterSchema = {
  username: usernameSchema,
  email: emailSchema,
  password: passwordSchema
}

const userLoginSchema = {
  email: emailSchema,
  password: passwordSchema
}

module.exports = { userRegisterSchema, userLoginSchema }