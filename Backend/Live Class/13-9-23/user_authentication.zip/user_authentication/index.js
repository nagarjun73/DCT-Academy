require('dotenv').config()
const express = require('express')
const cors = require('cors')
const { checkSchema } = require('express-validator')
const authenticateUser = require('./app/middlewares/authenticateUser')
const usersCltr = require('./app/controllers/user-cltr')
const greet = require('./app/controllers/greet')
const { userRegisterSchema, userLoginSchema } = require('./app/helpers/userValidationSchema')

const app = express()
const port = process.env.PORT || 3030

const configureDB = require('./config/db')
const routes = require('./config/routes')
configureDB()
app.use(express.json())
app.use(cors())

//routing level middle ware functon
app.post('/api/users/register', checkSchema(userRegisterSchema), usersCltr.register)
app.post('/api/users/login', checkSchema(userLoginSchema), usersCltr.login)
app.get('/api/users/account', authenticateUser, usersCltr.account)

app.get('/api/greet/welcome', authenticateUser, greet.welcome)
app.get('/api/greet/goodbye', greet.goodbye)


app.use('/', routes)


app.listen(port, () => {
    console.log('server running on port', port)
})