import Container from "./Components/Container"

function App() {

  return (
    <div>
      <Container />
    </div>
  )
}

export default App
