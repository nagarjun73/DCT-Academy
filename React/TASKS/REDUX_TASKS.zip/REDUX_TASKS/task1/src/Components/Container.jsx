import Display from "./Display"
import Form from './Form'

export default function Container(props) {
  return (
    <div>
      <Display />
      <Form />
    </div>
  )
}