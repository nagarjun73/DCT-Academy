import { useSelector } from 'react-redux'

export default function Display(props) {
  const users = useSelector((state) => {
    return state.users
  })

  return (
    <div>
      <h2>Listing Users - {users.data.length}</h2>
    </div>
  )
}