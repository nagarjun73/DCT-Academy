import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addUser, addInput } from '../actions/userAction'

export default function Form(props) {
  // const [name, setName] = useState('')

  const users = useSelector((state) => {
    return state.users
  })

  const dispatch = useDispatch()

  const onsubmithandle = (e) => {
    e.preventDefault()
    const formData = {
      name: users.input
    }
    dispatch(addUser(formData))
  }

  return (
    <div>
      <form onSubmit={onsubmithandle}>
        <label>Enter Name</label>
        <input type='text' value={users.input} onChange={(e) => dispatch(addInput(e.target.value))} />
        <input type='submit' />
      </form>
    </div>
  )
}