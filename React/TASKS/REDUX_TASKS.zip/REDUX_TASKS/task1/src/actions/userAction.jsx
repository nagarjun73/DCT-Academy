export const addUser = (users) => {
  return {
    type: "ADD_USER",
    payload: users
  }
}

export const addInput = (input) => {
  return {
    type: "ADD_INPUT",
    payload: input
  }
}