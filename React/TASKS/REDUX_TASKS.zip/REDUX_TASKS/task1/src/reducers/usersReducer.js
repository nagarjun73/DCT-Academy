const usersInitialState = {
  data: [],
  input: ''
}

export default function usersReducer(state = usersInitialState, action) {
  switch (action.type) {
    case "ADD_USER": {
      return { ...state, data: [...state.data, action.payload] }
    }

    case "ADD_INPUT": {
      return { ...state, input: action.payload }
    }
    default: {
      return { ...state }
    }
  }
}